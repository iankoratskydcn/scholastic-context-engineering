# Scholastic Context Engine: Master Plan

Status: working draft, built from spoken walkthroughs and text sessions on 2026-10-11 and 2026-10-12. This is the source document for the presentation to Dr. Kim (to be built in Claude Design on the lab template). Items marked **[OPEN]** are not yet decided.

---

## 1. One-Paragraph Summary

The Scholastic Context Engine takes a body of texts, extracts the logical structure of what each text claims, and tags every claim by the form of argument that supports it. It then recombines verified premises from unrelated sources (for example Kierkegaard, Hume, and recent AI literature) into a new, labeled argument that answers a question none of the sources answered. The result is run through a full scholastic disputation (objections, sed contra, respondeo, replies). Each stage gets its own targeted citation retrieval, and a final LLM pass writes the whole thing up in the style of Aquinas, grounded in the original source text. Throughout, a **strength model** (section 5) determines which of the competing arguments is best supported and why, so the final output presents its reasoning and not only its conclusion.

---

## 2. Motivation

Two problems drive the project.

1. **Hallucination in precise reasoning.** LLMs are weakest where reasoning must be exact and deductive. Common mitigations add more data or more context. They do not separate what is logically rigorous from what is loose, rhetorical, or merely reported.
2. **Context rot.** As context windows fill with undifferentiated text, the signal is diluted and the model loses track of what matters. Hallucination tends to enter at this point.

**Thesis:** If the context handed to the model is a compact, structured, source-grounded argument skeleton instead of raw text, both problems shrink. The model reasons over claims whose provenance and inferential role are known.

**Core capability (the crux of the project):** the system exists to let an LLM trace what *must* follow from what, and to say which of two competing lines of argument is better supported and why, instead of producing plausible-sounding philosophical text. The four-stage pipeline is the delivery mechanism. The strength model (section 5) is where the philosophical work happens.

---

## 3. What the Engine Produces

### 3.1 Single-document output

Given one document, the engine outputs a **deductive outline** of everything the text claims, affirms, implies, or otherwise states. Key properties:

- **Attribution-aware.** The outline records who asserts each claim, including claims the author reports and disagrees with ("Kant says X, but I think Y" keeps X and Y separate, with ownership and the disagreement relation preserved).
- **Logical relationships are the core value.** The claim inventory is scaffolding. The main product is the premise-to-conclusion structure: which claims support which, and what kind of inference connects them.
- **Form-tagged.** Each argument is tagged with its form from the taxonomy (see section 6), and premises are tagged by role (e.g., major, minor, conclusion).
- **Grounded and recursive.** For any premise, the engine can retrieve the passage in the source that establishes it. Each premise can in turn become a conclusion whose own support is traced, until it reaches bedrock (asserted without further support).

**Worked example:** "All men are mortal. Socrates is a man. Therefore Socrates is mortal."
Output: the major premise, minor premise, and conclusion are marked and typed. If the question "Is Socrates a man?" is asked, the engine pulls the supporting section of the source text so deductions can be made from it.

### 3.2 Multi-source output

Given multiple sources, the engine extracts conclusions, premises, and arguments from each into a shared library, then answers a posed question by assembling a **new** argument from pieces that never appeared together.

The assembly is **not limited to syllogism.** It draws on the full argument-form taxonomy (analogy, qiyas, a fortiori, abduction, and so on), choosing whichever form fits the available premises and the question. The synthesized argument is labeled by form, the same way the originals are.

---

## 4. Pipeline (Four Stages)

### Stage 1: Grounded extraction
Parse each source into attributed claims, premise/conclusion structure, and argument-form tags. Link every claim to its source passage. Trace premises recursively to bedrock.

### Stage 2: Cross-source synthesis
Given a question, search the premise/conclusion library across all sources. Find arguments of the relevant forms and assemble a novel, form-labeled argument chain. Output is an outline of that argument with citations to its component source claims.

**Common-ground step (runs before synthesis):** scan the premise pools of the opposing lines of argument (for example affirmative and denial) for overlap, and flag every premise that both sides assert or accept. These shared premises are the most trustworthy load-bearing material, because neither side has reason to attack them and both sides can reason from them. Synthesis builds from them first. Each candidate argument also gets its strength profile (section 5).

### Stage 3: Per-stage citation retrieval for the disputation
For each part of the scholastic structure (objections, sed contra, respondeo, replies to objections), run a **separate** database search keyed on:
- the **topics** of the relevant conclusions, and
- the **argument forms** involved.

Each stage gets its own context and citation set, independent of the others. This allows stages to run **in parallel** and keeps each context small and high-signal. The result is a citation set per stage, traceable to original sources. Each objection and reply is also recorded as an attack or support relation on the argument it targets, so that the disputation outcome (what survives all objections) feeds the strength model (section 5).

### Stage 4: Aquinas-style synthesis
A final LLM pass writes a full continuous article in the manner of Aquinas' *Summa*. Inputs are the per-stage citation sets and the original source text. Output is the complete disputation with citations attached to each argument.

```
Sources -> [1 Extraction + tagging + grounding] -> premise/conclusion library
Question -> [2 Cross-source synthesis]          -> novel tagged argument
         -> [3 Per-stage retrieval, parallel]   -> citations for objections / sed contra / respondeo / replies
         -> [4 Aquinas-style LLM write-up]      -> final article with citations
```

---

## 5. Strength Model

**Goal:** decide which arguments are best supported, in a way that is comparable across argument forms, and present the reasoning so that the final scholastic output can say not only what it concludes but why that conclusion beats its rivals. This is the central capability of the project (see section 2).

### 5.1 Principle

- **Strength is inherited, not intrinsic.** The strength of a conclusion is a property of what holds it up. The engine traces every premise back to bedrock (Stage 1) before saying anything about strength. Stage 1 already records who asserts each premise and whether it is asserted, reported, or disputed, which is exactly the data a defeat analysis needs.
- **Deductive relevance first.** If a chain is deductively valid and its premises hold, the conclusion holds and no weighing is needed. Strength-talk begins only where that fails or where a premise is itself contested. Then the conclusion rests on that premise, and whether the premise holds is a defeasible-reasoning question. This is why labeling every premise and every argument is a required part of the architecture.

### 5.2 Order of evaluation

1. **Deductive gate.** Valid, with all load-bearing premises holding: the argument holds.
2. **Shared ground.** Premises both sides accept are the strongest material to build from.
3. **Defeasible premise analysis.** For each contested premise, is it a genuine (prima facie) reason, and is it rebutted (a reason for the opposite conclusion) or undercut (a reason that this premise does not support this conclusion here)? Formal counterparts: abstract argumentation and structured argumentation (see 5.3).
4. **Dialectical standing after the disputation.** Which argument survives all objections, and who bears the burden of proof.
5. **Profile dominance.** Compare the remaining arguments across all other applicable methods (5.4).
6. **Numeric layer, last resort.** Used only to order arguments that are still incomparable after every structural method.

### 5.3 Methods recorded in each argument's strength profile

Each method is an independent evaluation. A method that does not apply to an argument's form is marked not applicable, never scored as zero. "Origin" names the source tradition. These attributions come from voice-session research and general knowledge and have **not** yet been verified through opened sources (see 5.7).

| Method | What it tests | Kind | Origin (to verify) |
|---|---|---|---|
| Deductive validity | Does the conclusion follow necessarily? | Binary gate | Classical logic |
| Shared ground | Do both sides accept the premise? | Counts | Aristotle, *endoxa* |
| Premise-status tier | Demonstrative, dialectical, or rhetorical/sophistical premises | Ordinal | Aristotle |
| Defeat analysis | Is each premise a reason, and is it rebutted or undercut? | Structural | Pollock; Dung; Prakken and Modgil (ASPIC+) |
| Disputation outcome | Does the argument survive all objections? Who bears the burden? | Structural | Scholastic disputation; dialectical burden of proof |
| Critical questions | Can the scheme's standard questions be answered? | Counts | Walton |
| Toulmin qualifier | The arguer's own signal of strength (warrant, backing, qualifier) | Recorded, not ranked | Toulmin |
| Coherence | Fit with accepted premises; cost of revision | Ordinal | Coherentism; Rawls (reflective equilibrium) |
| Explanatory comparison | Scope, simplicity, and fewer ad hoc assumptions versus a rival | Pairwise ordinal | Peirce; inference to the best explanation |
| Source authority | Kind of knowledge source and kind of authority | Ordinal | Nyaya *pramana*; Aquinas on authority |
| Proof standard | Graded standard met, from scintilla to beyond reasonable doubt | Ordinal | Carneades (Gordon, Prakken, Walton) |
| Scholastic probability | Probable, more probable, safer | Ordinal | Probabilism, probabiliorism, tutiorism |
| Ranking theory | Degrees of disbelief as integers | Numeric (secondary) | Spohn |
| Quantitative argumentation; Bayesian confirmation | Propagated strengths; how much evidence raises a hypothesis | Numeric (secondary) | QuAD-style semantics; Bayesian confirmation theory |

**Deliberately excluded:** virtue-theoretic evaluation (strength of the arguer's reasoning character rather than the argument), because it assesses the reasoner and not the reasoning.

**Why the Toulmin qualifier is not ranked:** it is the arguer grading their own argument. It is recorded because it is already present in the text and Stage 1 can extract it, but it is never treated as an independent check.

### 5.4 Combining methods: dominance, not a score

The intuition is that the best arguments rank highest on all scales together. The model implements that literally, as **Pareto dominance**: argument A dominates B if A is at least as high on every applicable scale the two share and strictly higher on at least one. Reasons for not using a weighted sum:

- A weighted sum needs weights, and the weights would be exactly the smuggled-in judgments the project worries about.
- Many scales are ordinal or incommensurable, and several apply only to some forms (for example, deductive validity does not apply to an analogy).
- Arguments that do not dominate each other are **reported as incomparable**, not forced into an order. The final output states that they are incomparable and why.

Arguments are grouped into dominance layers: layer 1 is the non-dominated set, layer 2 is non-dominated once layer 1 is removed, and so on. A layer is not a score.

### 5.5 Data structure

The strength profile is specified as JSON, stored with this document:

- `argument-case-schema.json`: JSON Schema (draft 2020-12), version 0.1.
- `argument-case-example.json`: a worked example with placeholder sources, validated against the schema.

One **case** per question. Each case has opposing positions, each holding arguments. Each argument records its form (taxonomy ID, tradition, classifier confidence, label status), its premises (role, rule kind, attribution, assertion status, *pramana*, bedrock, load-bearing, acceptance), a `strength_applicability` flag (standard, partial, none), and one evaluation per method with provenance (evaluator, confidence, rationale, evidence spans). The case also lists shared premises and carries a `ranking_policy` (tier order, Pareto aggregation, exclusion of non-applicable scales, and the low-to-high order of each ordinal scale) plus per-argument ranking results (dominance layer, dominates, dominated by, incomparable with).

### 5.6 Philosophical stance and acknowledged limitations

- **Reality is not strictly mathematical.** Mathematics can constrain and direct order without being the cause of anything, and mathematical description is analogical. The numeric layer is therefore an instrument, not a claim about what argument strength is.
- **Probability remains part of the picture and is a weakness to state in the paper.** Because the system uses LLMs, some quantification is unavoidable at the base. Every seed number is a human or model judgment that the mathematics then propagates, so the schema records where each seed score came from. Pollock argued against treating argument strength as probability (to verify).
- **Strength may not be comparable across kinds of argument.** Deductive arguments are valid or invalid rather than strong or weak, and for non-deductive arguments it is disputed whether strength can be compared across different kinds of support (Govier's "great divide," to verify). This is the reason "incomparable" is a legitimate output.
- **Some forms may not collapse to a standard scale at all.** Certain non-Western logics (for example the four-cornered *catuṣkoṭi*) permit statuses beyond true or false. The engine flags such arguments with `strength_applicability: none` instead of forcing a score. Not yet checked against sources.

### 5.7 Literature status

The traditions named in 5.3 and 5.6 were gathered during voice discussion and have not been verified the way section 8.1 was (opened pages, recorded URLs). To verify:

- The 2025 to 2026 work reported in voice research that tests LLM rankings of argument strength against quantitative argumentation semantics using rank correlation. It has not been located.
- Original sources for ASPIC+, Carneades, Dung's frameworks, ranking theory, and Walton's critical questions.
- Pollock's position on probability and degrees of justification.
- Govier's "great divide."
- The exact wording of Aquinas on arguments from authority (ST I q.1 a.8, as recalled) before it is used to order authority kinds.
- Whether prior work combines argumentation-framework strength with argument-form classification.

Next step: run the same five-agent verified literature review on this area.

### 5.8 Open items **[OPEN]**

- The low-to-high order inside each ordinal scale is a modeling choice. It needs review by the philosophers.
- Who fills each evaluation (Stage 1 labels, an LLM, a formal solver, or a human) and how evaluator reliability is checked. The blind protocol in 7.2 is the natural model.
- **Validating the ranking.** Proposal: have experts judge pairs of arguments blind on pilot questions, then compare their judgments with the dominance ordering and analyze the disagreements the way crosswalk errors are analyzed.
- How the final write-up presents incomparable arguments.
- How shared ground is detected across sources that never address each other, which requires deciding when two premises from different sources are the same claim.
- Where numeric seed scores come from, if the numeric layer is used.
- Mohist and Jain traditions (for example *syādvāda*) were noted for further exploration and have not been covered.

---

## 6. Argument-Form Taxonomy

The taxonomy does double duty: it is the **classifier's label set** (Stage 1) and the **toolbox for assembly** (Stage 2). The full detail lives in the separate taxonomy file; this is the condensed index.

- **Core:** categorical syllogism, modus ponens/tollens, disjunctive syllogism, reductio; generalization, statistical inference, abduction; analogical reasoning; defeasible reasoning, Socratic elenchus; non-argumentative statements
- **Medieval Latin:** supposition theory, insolubilia, theory of consequence, obligationes, syncategoremata, exponibilia, sophismata, Llullian combinatorics, Oxford Calculators
- **Islamic:** modal/hypothetical syllogism (Avicenna), qiyas
- **Indian (Nyaya):** five-membered inference, vyapti, pramana framework
- **Chinese:** bian (Mohist disputation), School of Names reference/predication puzzle
- **Hebrew poetic:** parallelism forms, a fortiori, better-than judgment, chiasm, pilpul
- **Early modern, 18th, 19th, and 20th century:** Cartesian deduction, Baconian induction, Leibniz, Port-Royal, Spinoza, Pascal, Hume, Kant, Mill, Boole, Peirce, Frege, Russell, Popper, Quine, and others (taxonomy still in progress)

**Design decisions already made:**
- The taxonomy is split into actual **argument forms** versus other categories (attributes, roles, rules, methods). The attribute values tag premises and meaning in the classifier.
- Persuasive, emotional, and rhetorical forms are **out of scope** for the core classifier. A separate cross-cultural fallacy catalogue will absorb them, along with manipulative stratagems and form-mismatch case studies.
- **No catch-all category.** Every span of text has some genuine logical structure, however faint. The classifier must commit to the best-fit specific form that the text's meaning reduces to, not pattern-match surface phrasing. Low confidence is allowed; a vague fallback label is not.
- Open taxonomy calls are deferred to Prof. Schultz.

---

## 7. Training the Classifier (Laya)

**What Laya is:** an open-source classifier that will be fine-tuned for argument-form and premise-type classification against our taxonomy.

**Goal:** fine-tune Laya using the annotated datasets already discovered. None of them describe arguments the way our taxonomy does, so the data is **semi-labeled**: lots of annotation, none of it exactly our labels.

**Core problem:** weak supervision with a label-space mismatch. Source datasets draw label boundaries differently and at different granularity. Because fine-tuning needs actual target labels (a prompt can tolerate ambiguity, a classifier head cannot), the mismatch has to be resolved into usable training targets. Labels must be inferred from the existing annotations rather than copied.

### 7.1 Label crosswalk

Map each dataset's labels to our taxonomy and record the mapping type: exact, partial, one-to-many, or no equivalent. Where a source label maps to several of our forms or only partly overlaps, use a **soft (probabilistic) target** during fine-tuning instead of forcing a hard pick.

**Method choices supported by the literature review (see 8.1 for citations):**
- **Never merge labels by name.** Same-named labels in different datasets can mean different things (for example, "premise" is a full clause in one corpus and a minimal span in another). Keep each dataset's labels separate and map them to taxonomy nodes explicitly.
- **Map to nodes in our hierarchy.** A coarse source label means "any descendant of this node." Train with a partial (marginal) loss over that set. Treat a one-to-many mapping as a partial-label problem.
- **Write mapping rules as labeling functions** and aggregate them with a label model (Snorkel-style), instead of hard-coding one pick per label. An LLM prompted with our definitions can add votes, with abstention allowed.
- **Draft the crosswalk with an LLM pass, then audit it by hand.** Disagreements between the draft and the blind gold labels (7.3) mark crosswalk errors.
- **Targets: blend soft and hard.** With only 2 to 5 raters per item, soft-only training is risky. Use soft targets from mapping weights for legacy data and rater vote shares for new data, and add a soft-label auxiliary head. Avoid plain uniform label smoothing, which discards the similarity between forms (for example abduction and analogy) that we want the model to keep.
- **Test transfer by holding out whole datasets.** Cross-dataset transfer is known to be weak in argument mining, so a crosswalk is required, not optional.

### 7.2 Blind human-in-the-loop labeling

A small web app for human verification:

1. The rater is shown an argument.
2. The rater picks the correct label from our taxonomy.
3. The machine's estimate is **not shown** during rating. Showing it first would anchor raters and contaminate the agreement numbers.
4. Raters: Ian, a few philosophy students, and Prof. Schultz.
5. Compute **inter-rater reliability** across raters on the same items, then reconcile disagreements into a single **gold label** per item.
6. Only after blind rating is complete is the machine's prediction compared with the gold label.

**Protocol details recommended by the literature review (8.1):**
- **Fully blind.** No model pre-labels, no model confidence, and no rater sees another rater's label before submitting. Studies of pre-labeled annotation found inflated scores for the model that supplied the pre-labels, and LLM suggestions raised annotator confidence without improving accuracy.
- **Add an "unsure / none fits" option** and an optional second-choice label.
- **Pilot first.** All raters label 40 to 50 items. Hold a disagreement meeting, revise the guidelines, and repeat once. Merge or split taxonomy categories based on the confusions.
- **Overlapping assignment.** Every item gets 2 to 3 raters, and a subset gets all raters.
- **Adjudication.** Auto-accept unanimous items. For disagreements, run a blind third-rater pass, or have the professor decide seeing only rater labels and not the model output. For persistent splits, discuss and classify each as guideline misapplication or genuine ambiguity.
- **Store everything.** Keep every raw label plus the adjudicated label and its type: unanimous, majority, adjudicated, or ambiguous. Genuinely ambiguous items stay in the set as soft or multi-label items and are not forced to one label.

### 7.3 What the gold set is used for

- **Independent evaluation set** for the fine-tuned classifier. It is not a self-fulfilling one, because the labels never saw the model's guess.
- **Correction signal for the crosswalk.** Where gold labels systematically diverge from what the crosswalk implied, revise that mapping. Model errors filtered through blind human judgment strengthen the crosswalk between the external datasets and our taxonomy. Review systematic model-versus-gold disagreements in a separate pass as candidate crosswalk errors, not only model errors.
- **Calibration data** for the model's confidence. The no-fallback rule means low-confidence commitments must be measurable. Compare the predicted distribution with the human distribution per item. Do not judge calibration with standard expected calibration error against a majority label, which is theoretically problematic when raters disagree.
- **Small trusted set** for noise-robust training. The gold labels can anchor loss correction when fine-tuning on weak labels, and they keep the model from propagating pseudo-label errors.

**Evaluation rules:**
- Freeze gold labels before unmasking any model prediction.
- Report accuracy on unanimous items and on all items separately, stratified by agreement level. Models tend to do well on high-agreement items and near chance on low-agreement ones.
- Report soft metrics (cross-entropy against the rater distribution) on all items.
- Draw the evaluation gold set as a stratified random sample, stratified by category and source dataset, with a floor for rare categories. A second slice chosen by model uncertainty or crosswalk conflict is allowed, but log its inclusion probabilities and use importance-weighted estimates. Uncertainty-selected items are fine for training data, not for unweighted accuracy or calibration estimates.
- After freezing, check each rater's agreement with the model for raters who match it unusually closely.

### 7.4 Open items **[OPEN]**

- Which open-source base classifier, and full fine-tune versus adapter-based tuning.
- Inventory of the discovered datasets: what each labels, definitions, size, license, annotation quality. For each, record whether it labels rhetorical role, argument scheme, fallacy, or stance, since the review found no corpus that labels formal inference form or major/minor premise role.
- Agreement statistic. Recommended: Krippendorff's alpha (nominal) with bootstrap 95% confidence intervals, overall and per category group, plus Gwet's AC2 as a prevalence-robust check, raw agreement, and a rater-versus-rater confusion matrix. Also run alpha at the coarse hierarchy level. Do not apply fixed thresholds mechanically; judge agreement relative to the task. Still open: the threshold for accepting a gold label without further reconciliation.
- Sampling strategy for what goes to raters (see evaluation rules in 7.3). Still open: the split between the random slice and the uncertainty slice.
- Rater training and a shared guideline document, so disagreement reflects genuine ambiguity and not different readings of the taxonomy. Consider a decision-procedure style guideline, as used in earlier scheme-annotation work.
- Scope of the rating app. It is an internal tool, so keep it minimal. It must store per-rater labels, the unsure option, and sampling probabilities.
- Whether to keep rater IDs and train per-rater heads (needs enough labels per rater) or only a shared soft-label head.

### 7.5 Expected difficulty

Published work suggests this is a hard annotation and classification problem. Role labels (claim, premise) reach kappa of about 0.6 to 0.9. Scheme-level labels fall to about 0.2 to 0.7, with 0.39 on the most comparable real-text corpus. On that corpus the best LLM scored about 30 F1 against about 62 for fine-tuned RoBERTa, and near-perfect scores appear only on synthetic, templated text. A single annotator with 15 or more fine labels is unlikely to be reliable. Plan to collapse to coarser families using our hierarchy, report results at both levels, and expect wide confidence intervals for rare categories. None of this work covers non-Western forms (qiyas, Nyaya).

---

## 8. Prior Research

To be filled from the Hermes literature review (Google Scholar, 20 parallel agents, one per subtopic). Expected clusters:

- LLM hallucination, including in logical/deductive reasoning
- Long-context degradation and context compression / context engineering
- RAG, chain-of-thought and its faithfulness limits
- Neuro-symbolic and LLM + formal-logic hybrids
- Argument mining and argumentation schemes in NLP; fallacy detection
- Deductive reasoning benchmarks
- Premise selection
- Computational treatments of historical and non-Western logics
- LLMs for philosophy and evaluation of AI-authored philosophical writing
- Structure-based context pruning (first entries in 8.1)
- Argument strength: philosophical and computational treatments (not yet reviewed; see 5.7)

**Priority flag:** check first whether anyone already does argument-form classification for context selection. If so, the gap statement changes.

**Gap statement (draft, to be verified against the literature):** no one extracts an attribution-aware, form-tagged deductive skeleton from multiple sources across traditions, recombines it into new arguments, and then generates a disputation with per-stage citation retrieval.

### 8.1 Verified so far: classifier training and annotation methodology

Source: five parallel literature-review agents run 2026-10-12, covering soft labels, label-space unification, weak supervision, the argument-mining dataset landscape, and annotation verification. Each citation below was taken from a page an agent opened. **Most agents read abstracts or landing pages, not full papers, so read each paper before citing it.** Several entries are arXiv preprints without a confirmed venue, marked "preprint."

**Do not cite:** "Ivanova et al., 2024" (claimed 6 to 8 point zero-shot gain from automatic label harmonisation in argument mining). It appeared in a survey snippet, and a search found no such paper. Treat it as unverified.

#### Soft labels and learning from annotator disagreement

| Citation | URL | Use for us |
|---|---|---|
| Uma, Fornaciari, Hovy, Paun, Plank, Poesio 2021. Learning from Disagreement: A Survey. JAIR 72 | https://mlanthology.org/jair/2021/uma2021jair-learning | Soft-only training wins only with many judgments per item. With few raters, blend soft and gold. |
| Fornaciari et al. 2021. Beyond Black & White: Soft-Label Multi-Task Learning. NAACL | https://aclanthology.org/2021.naacl-main.204 | Cheap baseline: hard-label head plus soft-label auxiliary head. |
| Davani, Díaz, Prabhakaran 2022. Dealing with Disagreements. TACL 10 | https://aclanthology.org/2022.tacl-1.6/ | Per-rater subtask heads. Tested on binary tasks only. |
| Heinisch, Orlikowski, Romberg, Cimiano 2023. Architectural Sweet Spots for Modeling Human Label Variation (argument quality). EMNLP | https://aclanthology.org/2023.emnlp-main.687 | Argument-mining evidence that relating annotators helps. |
| Nie, Zhou, Bansal 2020. What Can We Learn from Collective Human Opinions on NLI Data? EMNLP | https://aclanthology.org/2020.emnlp-main.734 | Stratify accuracy by agreement level. Models fail on low-agreement items. |
| Baan, Aziz, Plank, Fernandez 2022. Stop Measuring Calibration When Humans Disagree. EMNLP | https://aclanthology.org/2022.emnlp-main.124 | Do not use majority-label calibration. Use instance-level measures. |
| Plank 2022. The "Problem" of Human Label Variation. EMNLP | https://aclanthology.org/2022.emnlp-main.731 | Framing: variation is signal. Includes a repository of un-aggregated datasets. |
| Peterson, Battleday, Griffiths, Russakovsky 2019. Human Uncertainty Makes Classification More Robust. ICCV | https://mlanthology.org/iccv/2019/peterson2019iccv-human/ | Foundational evidence for soft targets (about 50 raters per item, so not directly comparable). |
| Müller, Kornblith, Hinton 2019. When Does Label Smoothing Help? NeurIPS | https://papers.nips.cc/paper/8717-when-does-label-smoothing-help | Uniform smoothing erases class similarity. Prefer structured soft targets. |
| Leonardelli et al. 2023. SemEval-2023 Task 11: Learning with Disagreements. | https://aclanthology.org/2023.semeval-1.314 | Soft evaluation protocols to borrow. |

#### Label-space unification and hierarchical labels

| Citation | URL | Use for us |
|---|---|---|
| Beryozkin, Drori, Gilon, Hartman, Szpektor 2019. A Joint Named-Entity Recognizer for Heterogeneous Tag-sets Using a Tag Hierarchy. ACL | https://aclanthology.org/P19-1014/ | Closest template: datasets with different tag-sets linked by a hierarchy. Sequence tagging, not classification. |
| Abhishek, Azad, Ganesan, Anand, Awekar 2018. Collective Learning From Diverse Datasets for Entity Typing in the Wild. (preprint) | https://arxiv.org/abs/1810.08782 | Unified hierarchy, label mapping, and partial loss in one classifier. Nearest recipe to ours. |
| Feger, Boland, Dietze 2025. Limited Generalizability in Argument Mining. ACL | https://aclanthology.org/2025.acl-long.1164/ | 97% of cross-dataset runs fall below the in-dataset mean. Pooling helps. A crosswalk is required. |
| Zhi et al. 2020. Partially-Typed NER Datasets Integration. (preprint) | https://arxiv.org/abs/2005.00502 | Theory that treating each dataset as partially annotated is workable. |
| Zhou et al. 2020. Hierarchy-Aware Global Model for Hierarchical Text Classification (HiAGM). ACL | https://aclanthology.org/2020.acl-main.104/ | Taxonomy-aware head over our tradition/category tree. |
| Ma, Huang, Haensch 2025. Can Large Language Models Advance Crosswalks? NAACL SRW | https://aclanthology.org/2025.naacl-srw.38 | LLM-drafted crosswalks between classification systems. Occupation codes, not annotation schemes. |
| Savigny, Yun 2025. AMELIA. (preprint) | https://arxiv.org/abs/2508.17926 | Pools 19 argument-mining datasets in one format. The page does not say how labels were reconciled. |

#### Weak supervision and cross-label-space transfer

| Citation | URL | Use for us |
|---|---|---|
| Kennerley, Aviles-Rivero, Schönlieb, Tan 2026. Mind the Gap: Transferring Labels to Align Object Detection Datasets. CVPR | https://arxiv.org/abs/2506.04737 | Closest structural match: no example has labels in both spaces. Do not merge same-named classes. Vision only. |
| Ratner, De Sa, Wu, Selsam, Ré 2016. Data Programming. (preprint) | https://arxiv.org/abs/1605.07723 | Mapping rules as labeling functions with learned accuracies. |
| Ratner et al. 2017. Snorkel. | https://arxiv.org/abs/1711.10160 | Reference implementation of the label-model step. |
| Ratner et al. 2018. Training Complex Models with Multi-Task Weak Supervision. (preprint) | https://arxiv.org/abs/1810.02840 | Sources labeling at different granularities. Needs a hand-specified hierarchy. |
| Feng et al. 2020. Provably Consistent Partial-Label Learning. (preprint) | https://arxiv.org/abs/2007.08929 | One-to-many mappings as candidate label sets. |
| Smith, Fries, Hancock, Bach 2022. Language Models in the Loop. (preprint) | https://arxiv.org/abs/2205.02318 | LLM prompt answers as labeling-function votes with abstention. |
| Yu et al. 2021. COSINE: Contrastive-Regularized Self-Training. NAACL | https://aclanthology.org/2021.naacl-main.84/ | Fine-tune a pretrained classifier on noisy weak labels. |
| Hendrycks, Mazeika, Wilson, Gimpel 2018. Using Trusted Data to Train Deep Networks on Labels Corrupted by Severe Noise. (preprint) | https://arxiv.org/abs/1802.05300 | Gold set as the trusted set. Its noise model may not fit systematic crosswalk errors. |
| Wang, Kim, Miao, Mitra, Rahman 2024. Human-LLM Collaborative Annotation Through Effective Verification of LLM Labels. CHI | https://megagon.ai/publications/human-llm-collaborative-annotation-through-effective-verification-of-llm-labels/ | Silver labels from an LLM, humans re-annotate the lowest-confidence ones. |
| Jin, Wanner, Kadam, Shvets 2023. Towards Weakly-Supervised Hate Speech Classification Across Datasets. WOAH | https://aclanthology.org/2023.woah-1.4/ | Nearest NLP analogue: divergent annotation schemata, class-name-only supervision. |

#### Argument mining landscape (what exists and how reliable it is)

| Citation | URL | What it shows |
|---|---|---|
| Li, Schlegel, Sun, Batista-Navarro, Nenadic 2025. Large Language Models in Argument Mining: A Survey. (draft preprint, v6) | https://arxiv.org/html/2506.16383v6 | Confirms label interoperability is ad hoc and there is no canonical schema. Not peer-reviewed. |
| Lawrence, Reed 2019. Argument Mining: A Survey. Computational Linguistics 45(4) | https://aclanthology.org/J19-4006/ | Foundational framing. Abstract read only. |
| Stab, Gurevych 2017. Parsing Argumentation Structures in Persuasive Essays. Computational Linguistics 43(3) | https://arxiv.org/pdf/1604.07370 | 402 essays. Component kappa .64 to .88. Role labels, no inference-form label. |
| Visser, Lawrence, Reed, Wagemans, Walton 2021. Annotating Argument Schemes. Argumentation 35(1) | https://dare.uva.nl/id/ca27044c-f6a9-491e-a9e7-d5c738559e8b | Walton and Periodic Table scheme corpora. Abstract read only. |
| Lawrence, Visser, Reed 2019. An Online Annotation Assistant for Argument Schemes. LAW XIII | https://aclanthology.org/W19-4012/ | Decision-tree annotation method (ASK). Kappa 0.72 reported secondhand. |
| Ruiz-Dolz, Kikteva, Lawrence 2025. Mining Complex Patterns of Argumentative Reasoning in Natural Language Dialogue. ACL | https://aclanthology.org/2025.acl-long.368.pdf | Most direct comparator. 24 schemes, kappa 0.39, best LLM about 30 F1 versus 62 for RoBERTa at family level. |
| Ruiz-Dolz et al. 2024. NLAS-multi. (preprint) | https://arxiv.org/html/2402.14458v1 | Synthetic data gives near-perfect F1 that does not show general scheme classification. |
| Robbani et al. 2024. Flee the Flaw. EMNLP | https://preview.aclanthology.org/setup/2024.emnlp-main.1142 | Slot-filling templates for implicit logical structure. Alpha 0.54. Fallacies only. |
| Sathish 2026. Pramana. (preprint) | https://arxiv.org/pdf/2604.04937 | Only Nyaya-based LLM work found. 55 examples, reasoning traces, not a span classifier. |

#### Annotation verification methodology

| Citation | URL | Use for us |
|---|---|---|
| Artstein, Poesio 2008. Inter-Coder Agreement for Computational Linguistics. Computational Linguistics 34(4) | https://www.cl.cam.ac.uk/teaching/1516/R216/Artstein.pdf | Use Krippendorff's alpha for many raters and missing cells. Thresholds are task-relative. |
| James 2026. Counting on Consensus: Selecting the Right IAA Metric. (preprint) | https://arxiv.org/html/2603.06865 | Report alpha with confidence intervals plus Gwet's AC2. Fleiss' kappa needs equal ratings per item. |
| Xu, Jurgens 2026. Beyond Consensus: Perspectivist Modeling and Evaluation of Annotator Disagreement in NLP. (preprint, year inferred from ID) | https://arxiv.org/html/2601.09065v1 | Alpha and kappa conflate ambiguity with unreliability. Keep per-item distributions. |
| Pavlick, Kwiatkowski 2019. Inherent Disagreements in Human Textual Inferences. TACL 7 | https://aclanthology.org/Q19-1043/ | Disagreement persists with more raters. Keep ambiguous items. |
| Berzak et al. 2016. Anchoring and Agreement in Syntactic Annotations. (preprint, venue unconfirmed) | https://arxiv.org/abs/1605.04481 | Correction-based gold sets inflate the pre-labeling parser's score. Direct support for blind rating. |
| Schroeder, Roy, Kabbara 2025. Just Put a Human in the Loop? (preprint) | https://arxiv.org/abs/2507.15821 | LLM suggestions raised confidence and shifted label distributions without speeding annotation. Crowdworkers, not experts. |
| Prabhu et al. 2019. Sampling Bias in Deep Active Classification. (preprint) | https://arxiv.org/abs/1909.09389 | Uncertainty sampling is acceptable for training data, not a neutral way to build an evaluation set. |
| Kossen, Farquhar, Gal, Rainforth 2021. Active Testing. ICML | https://arxiv.org/abs/2103.05331 | Non-uniform test sampling biases evaluation. Use importance weights. Author list not confirmed by the agent. |
| Boudoua et al. 2026. Guidelines for the Creation of an Annotated Corpus. (practitioner preprint) | https://www.alphaxiv.org/abs/2601.13353 | Template for the pilot and guideline loop, with an "I don't know" label. |

#### Findings that bear on novelty and publishability

- **No verified work derives soft labels from a taxonomy crosswalk.** The closest are Abhishek 2018, Beryozkin 2019, and Feng 2020, all outside argument mining. The crosswalk-to-soft-target step is ours to validate empirically.
- **No annotated corpus labels formal inference form or major/minor premise role.** Existing corpora label rhetorical role, scheme, fallacy, or stance.
- **No annotated resource exists for non-Western forms** (qiyas, Nyaya). Pramana (55 examples) is the only Nyaya-based work found.
- **Novelty threat for context selection:** no paper was found that classifies argument form to select or compress context. This is a weak negative from a limited search. The nearest neighbors prune reasoning chains by step role, not argument form (see the related-work table below): Zhao et al. 2025 and Sarwar et al. 2026. The Lawrence/Reed/Ruiz-Dolz group owns the scheme-mining pipeline and could extend it. Still to do: a targeted search for argument schemes combined with retrieval, summarisation, and context-window terms.

#### Related work: structure-based context pruning

| Citation | URL | What it shows | Difference from ours |
|---|---|---|---|
| Sarwar, Chakraborty, Kapusuzoglu, Lee, Das, Rawls, Balasubramaniam, Sahu 2026. Structured Thoughts for Improved Reasoning and Context Pruning. (v1 preprint, cs.CL, 11 Jul 2026) | https://arxiv.org/abs/2607.10386 | Splits a model's own reasoning trace into scratch-work blocks and one-sentence outcome blocks, fine-tunes on that format (+3.66% on Llama-Nemotron-8B, +8.08% on Qwen2.5-7B over standard fine-tuning, math benchmarks), then prunes the scratch work for about 85% context savings at an 8.76% accuracy drop (one model). Cites "lost in the middle" and the finding that longer reasoning chains can hurt, which supports our context-rot motivation. | Segments by filler-word heuristics, with no argument-form classification. Prunes within one model's chain of thought by step role. Math only, no multi-source grounding or attribution. Its limitations section admits segmentation is crude and wrongly summarized outcomes lose information. Read pages 1 to 10 of 13. |
| Zhao et al. 2025. Can Pruning Improve Reasoning? (Prune-on-Logic) | https://arxiv.org/abs/2505.14582v2 | Converts long chains of thought into logic graphs and prunes low-utility steps. | Prunes reasoning steps by structural role, not argument form. Abstract page only. |

**Status of the novelty check:** Sarwar et al. was read directly and is not a threat to the form-classification claim. It is useful as related work and as support for the motivation.

#### Coverage gaps in this review

- Not searched: confident learning and other label-error-detection methods, Krippendorff's and Gwet's original papers, and rater-training literature for philosophy tasks.
- Distillation with ambiguous labels and calibration after soft-label training were covered only indirectly.
- No guidance was found on how many raters per item are enough, on adjudication protocol comparisons, or on active-learning evaluation with noisy expert labels.

---

## 9. Application: AI Philosophy Competition

The engine is the methodology half of the entry to the AI Philosophy Competition (1st edition; organizers Zachary Goodsell and Elliott Thornley; funded by Forethought Research).

- Up to three essays (max 6,000 words each) plus a methodology report; work must be primarily AI-generated with minimal human collaboration; judged blind by academic philosophers; **deadline October 31, 2026.**
- Two papers in one: the methodology (this engine) and the philosophical essay it produces.
- Prof. Schultz interacts with the system, likely through a question-and-answer interface. Ian builds the engine.
- Priority (stated 2026-10-12): the October 31 deadline may or may not be met, and that is acceptable. The primary aim is a system that functions well, because the work looks publishable independently of the competition.
- Scope limit: a model built specifically around premise-deduction capacity is out of reach for this deadline and is a candidate for a separate paper.

---

## 10. Plan and Next Steps

1. Run the Hermes literature review (Google Scholar, parallel agents). The Sarwar et al. paper has been read and is not a threat. Still run the targeted search for argument schemes combined with retrieval, summarisation, and context-window terms.
2. Run a verified literature review for the strength model (5.7).
3. Finalize taxonomy index and the argument-forms versus attributes split with Prof. Schultz.
4. Inventory the discovered datasets and build the label crosswalk (7.1).
5. Build the blind rating app (7.2); recruit student raters; write rater guidelines.
6. Collect gold labels, compute inter-rater reliability, revise the crosswalk, fine-tune Laya.
7. Build Stage 1 (extraction, tagging, grounding) on a small pilot set of sources.
8. Build Stage 2, including the common-ground step, and test on one cross-source question using sources such as Kierkegaard, Hume, and a recent AI paper.
9. Build Stage 3 (per-stage parallel retrieval) and Stage 4 (Aquinas-style write-up).
10. Implement the strength profile (section 5): fill the evaluations for the pilot arguments, compute dominance layers, and validate against blind expert pairwise judgments (5.8).
11. Generate the essay(s) and write the methodology report.
12. Build the presentation for Dr. Kim in Claude Design using the lab template: motivation, prior research, next steps.

**Timing:** the October 31 competition deadline is under three weeks out and may or may not be met, which is acceptable. The primary aim is a system that functions well. Steps 4 to 6 (crosswalk, rating app, rater recruitment, fine-tuning) and step 10 are the likeliest to overrun. Decide soon what the competition entry needs from Laya and the strength model versus what can wait for a follow-up paper. **[OPEN]**

---

## 11. Open Questions

- Base model and tuning approach for Laya (7.4).
- Which datasets, and how clean are the crosswalks?
- Agreement statistic and acceptance threshold (7.4).
- Pilot corpus: which texts, and which question first?
- How is "bedrock" detected, and how are attribution and disagreement represented in the data model?
- How is Stage 4 output evaluated for faithfulness to the cited source text?
- Which taxonomy decisions remain with Prof. Schultz?
- Competition scope: does the entry require the fine-tuned Laya, or can Stage 1 use a prompted LLM as a stopgap?
- Strength model: order within each ordinal scale, who fills each evaluation, how the ranking is validated, and how incomparable results are presented (5.8).
- How to detect that premises from different sources are the same claim, which both the common-ground step and shared-ground evaluation depend on.
- Literature for the strength model has not been verified yet (5.7).
