# Export Contents

- `conversation_transcript.md` — user-visible transcript of the argument-extraction discussion.
- `argument_extraction_methodology_flowchart.html` — generated methodology flow chart.

The export excludes system/developer instructions, internal reasoning, and tool internals.
